package org.javapatil.dinine;

public class Receipt {
	private int rno;
	private String rdate;
	private int ramt;
	
	public Receipt(int rno, String rdate, int ramt) {
		super();
		this.rno = rno;
		this.rdate = rdate;
		this.ramt = ramt;
	}
	
	void displayReceipt()
	{
	  System.out.println(rno + " " + rdate + " " + ramt);	
	}
	
}
