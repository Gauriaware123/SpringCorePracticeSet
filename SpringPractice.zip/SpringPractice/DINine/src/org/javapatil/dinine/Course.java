package org.javapatil.dinine;

import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class Course {
	private String cid;
	private String cname;
	private Map<Student, ReceiptList> studentWiseReceipts;
	
	public Course(String cid, String cname, Map<Student, ReceiptList> studentWiseReceipts) {
		super();
		this.cid = cid;
		this.cname = cname;
		this.studentWiseReceipts = studentWiseReceipts;
	}
	
	void displayCourse()
	{
		System.out.println("Course ID: " + cid);
		System.out.println("Course Name: " + cname);
		
		System.out.println("**** Student Wisr Receipts ****");
		
		Set<Entry<Student, ReceiptList>> set=studentWiseReceipts.entrySet();
		Iterator<Entry<Student, ReceiptList>> it=set.iterator();
		Entry<Student, ReceiptList> e=null;
		Student s=null;
		ReceiptList recList=null;
		
		while(it.hasNext()){
			e=it.next();
			s=e.getKey();
			recList=e.getValue();
			
			s.displayStudent();
			
			recList.displayReceiptList();
		}
			
		
		
		
	}
	
}
