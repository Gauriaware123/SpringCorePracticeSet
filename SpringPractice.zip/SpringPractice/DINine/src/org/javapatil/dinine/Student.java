package org.javapatil.dinine;

public class Student {
	private int sno;
	private String sname;
	private int age;
	
	public Student(int sno, String sname, int age) {
		super();
		this.sno = sno;
		this.sname = sname;
		this.age = age;
	}
	
	void displayStudent()
	{
		System.out.println(sno + " " + sname + " " + age);		
	}
}
