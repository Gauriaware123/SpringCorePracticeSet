package org.javapatil.dinine;

import java.util.List;

public class ReceiptList {
  private List<Receipt> receipts;

public ReceiptList(List<Receipt> receipts) {
	super();
	this.receipts = receipts;
}
  
void displayReceiptList()
{
	System.out.println("");
	
	for(Receipt r: receipts){
		r.displayReceipt();
	}
		
	System.out.println("");
}
  
}
