package org.javapatil.diseven;

public class Receipt {
	private int rno;
	private String rdate;
	private int ramt;
	
	public Receipt(int rno, String rdate, int ramt) {
		super();
		this.rno = rno;
		this.rdate = rdate;
		this.ramt = ramt;
	}

	public void displayReceipt() {
      System.out.println(rno + " " + rdate + " " + ramt);    		
	}
	
	
}
