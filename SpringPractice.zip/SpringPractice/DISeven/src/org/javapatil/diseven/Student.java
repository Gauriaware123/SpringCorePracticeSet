package org.javapatil.diseven;

import java.util.List;

public class Student {
	private int sno;
	private String sname;
	private int age;
	private List<Receipt> receipts;
	
	public Student(int sno, String sname, int age, List<Receipt> receipts) {
		super();
		this.sno = sno;
		this.sname = sname;
		this.age = age;
		this.receipts = receipts;
	}

	void displayStudent()
	{
	  System.out.println(sno + " " + sname + " " + age);
	  System.out.println("****** Receipts ******");
	  
	  for(Receipt r: receipts)
	  {
		  r.displayReceipt();
	  }

	}
	
}
