package org.javapatil.dieight;

import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class Student {
	private int sno;
	private String sname;
	private int age;
	private Map<String, String> subjectWiseMarks;
	
	public Student(int sno, String sname, int age, Map<String, String> subjectWiseMarks) {
		super();
		this.sno = sno;
		this.sname = sname;
		this.age = age;
		this.subjectWiseMarks = subjectWiseMarks;
	}
	
	void displayStudent()
	{
		System.out.println(sno + " " + sname + " " + age);
		System.out.println("****** Subject Wise marks ******");
		
		Set<Entry<String, String>> set=subjectWiseMarks.entrySet();
		Iterator<Entry<String, String>> it=set.iterator();
		Entry<String, String> e=null;
		String subject="";
		String marks="";
		
		
		while(it.hasNext())
		{
			e=it.next();
			subject=e.getKey();
			marks=e.getValue();
			System.out.println(subject + " " + marks);
		}
		
	}
	
}
